from re import X
from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.
#require -> response
#action in django its called a view. 
#in django it is called a template. 

def calculate():
    x = 1
    y = 2
    return x

def say_hello(request):
    x=calculate()
    #pull data from db
    #return HttpResponse('Hello World')
    return render(request, 'hello.html', {'name': 'Mosh'})